import requests
import json
from PyQt6.QtWidgets import QFileDialog, QTextEdit, QMainWindow, QLabel, QPushButton, QLineEdit, QApplication, QVBoxLayout, QWidget
import sys


class Example(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setGeometry(300, 300, 300, 300)
        
        # Create widgets
        self.line = QLineEdit(self)
        self.label = QTextEdit(self)
        self.label.setReadOnly(True)
        self.button = QPushButton('Вывод JSON', self)
        self.button.clicked.connect(self.run)
        
        # Create layout and add widgets to it
        layout = QVBoxLayout()
        layout.addWidget(self.line)
        layout.addWidget(self.label)
        layout.addWidget(self.button)
        
        # Create a central widget and set the layout on it
        central_widget = QWidget()
        central_widget.setLayout(layout)
        
        # Set the central widget of the QMainWindow
        self.setCentralWidget(central_widget)

    def run(self):
        interested_in = ['company','created_at','email','id','name','url']
        api = f'https://api.github.com/users/{self.line.text()}'
        user_data = requests.get(api).json()
        json_data = dict(zip(interested_in, list(user_data.get(i) for i in interested_in)))
        
        self.label.setText(f'{json_data}')

        fileName = QFileDialog.getSaveFileName(self, "Save File", "res", "Json Files (*.json);;All Files (*)")
        if fileName:
            try:
                with open(f"{fileName[0]}.json", 'w') as wr:
                    json.dump(json_data, wr)
            except Exception as exp:
                self.label.setText(f"Exeption caught while saving: {exp}")
        


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec())